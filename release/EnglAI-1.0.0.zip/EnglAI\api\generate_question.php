<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../src/Security/RateLimiter.php';

use EnglAI\AI\AIContentService;
use EnglAI\AI\ContentValidator;
use EnglAI\AI\FallbackProvider;
use EnglAI\AI\GeminiProvider;
use EnglAI\Security\RateLimiter;

function fail(string $message, int $status = 400): never
{
    json_response([
        'success' => false,
        'message' => $message
    ], $status);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('Gunakan metode POST.', 405);
}

$clientKey = ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . '|generate-question';
if (!RateLimiter::check($clientKey, 30, 60)) {
    fail('Terlalu banyak permintaan. Tunggu sebentar lalu coba kembali.', 429);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input)) {
    fail('Payload tidak valid.');
}

$mode = ($input['mode'] ?? 'quiz') === 'speaking'
    ? 'speaking'
    : 'quiz';

$difficulty = in_array(
    $input['difficulty'] ?? '',
    ['easy', 'medium', 'hard'],
    true
)
    ? $input['difficulty']
    : 'medium';

$unit = max(1, min(99, (int)($input['unit'] ?? 1)));

try {
    $rpp = db()->query("
        SELECT id, original_name, extracted_text
        FROM rpps
        WHERE is_selected = 1
        ORDER BY id DESC
        LIMIT 1
    ")->fetch();
} catch (Throwable $e) {
    app_log('error', 'RPP database lookup failed', ['request_id' => request_id(), 'exception' => get_class($e)]);
    fail('Database RPP tidak dapat diakses.', 500);
}

if (!$rpp) {
    fail('Guru belum memilih RPP aktif. Pilih RPP melalui halaman admin.', 422);
}

$material = trim((string)$rpp['extracted_text']);

if ($material === '') {
    fail('Isi RPP aktif tidak dapat dibaca. Unggah RPP lain.', 422);
}

$material = mb_substr($material, 0, 30000);

if ($mode === 'speaking') {

    $prompt = "Anda adalah pelatih pronunciation bahasa Inggris untuk siswa SMP Indonesia.

Gunakan HANYA materi RPP berikut.

Jangan mengambil informasi dari luar RPP.

Buat SATU latihan pronunciation.

Kembalikan JSON valid saja:

{
\"phrase\":\"...\",
\"tips\":\"...\",
\"exp\":\"...\",
\"cat\":\"Pronunciation\",
\"dif\":\"{$difficulty}\",
\"u\":{$unit}
}

RPP:
{$material}";

} else {

    $prompt = "Anda adalah pembuat soal Bahasa Inggris SMP.

Gunakan HANYA materi RPP berikut.

Jangan mengambil informasi dari luar RPP.

Buat tepat SATU soal pilihan ganda.

4 opsi.
1 jawaban benar.

Kembalikan JSON valid saja:

{
\"u\":{$unit},
\"q\":\"...\",
\"op\":[\"A...\",\"B...\",\"C...\",\"D...\"],
\"ans\":\"A\",
\"exp\":\"...\",
\"cat\":\"Grammar\",
\"dif\":\"{$difficulty}\"
}

RPP:
{$material}";
}

$provider = new GeminiProvider(
    getenv('GEMINI_API_KEY') ?: '',
    getenv('GEMINI_MODEL') ?: 'gemini-2.5-flash',
    max(5, min(60, (int) (getenv('GEMINI_TIMEOUT_SECONDS') ?: 45)))
);
$service = new AIContentService(
    $provider,
    new FallbackProvider(),
    new ContentValidator(),
    3,
    static function (string $level, string $message, array $context): void {
        $context['request_id'] = request_id();
        app_log($level, $message, $context);
    }
);
try {
    $serviceResponse = $service->generate($mode, $prompt, $unit, $difficulty);
} catch (Throwable $e) {
    app_log('error', 'AI and fallback generation failed', [
        'request_id' => request_id(),
        'mode' => $mode,
        'exception' => get_class($e),
    ]);
    fail('Materi AI dan fallback tidak tersedia. ID laporan: ' . request_id(), 503);
}
$result = $serviceResponse['data'];

$result['u'] = $unit;
$result['dif'] = $difficulty;

if (
    $mode === 'quiz' &&
    (
        !isset($result['q'], $result['op'], $result['ans']) ||
        !is_array($result['op']) ||
        count($result['op']) !== 4 ||
        !in_array($result['ans'], ['A', 'B', 'C', 'D'], true)
    )
) {
    fail('Format soal Gemini tidak lengkap.', 502);
}

if (
    $mode === 'speaking' &&
    !isset($result['phrase'])
) {
    fail('Format latihan Gemini tidak lengkap.', 502);
}

json_response([
    'success' => true,
    'source' => $serviceResponse['source'],
    'warning' => $serviceResponse['warning'] ?? null,
    'rpp_id' => (int)$rpp['id'],
    'data' => $result
]);
